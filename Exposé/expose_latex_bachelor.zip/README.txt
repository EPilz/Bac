################################################################################
#
# README for writing an exposé in LateX 
#
################################################################################

Use this template to write an exposé for a thesis or project carried out at INSO.


For general help about using the templates and for help with LateX, please consult 
the top-level README.txt file.

 